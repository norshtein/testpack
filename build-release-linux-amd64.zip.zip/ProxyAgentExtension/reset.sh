#!/bin/bash
set script_dir=%~dp0
%script_dir%\ProxyAgentExt.exe reset
